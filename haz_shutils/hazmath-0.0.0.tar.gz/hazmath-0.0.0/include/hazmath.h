/*******************************************************************/  
/* This header file was automatically generated with "make headers".   */
/* WARNING: DO NOT EDIT!!!                               */  
/*******************************************************************/  

// Standard Includes
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <getopt.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <assert.h>
// Internal Includes
#include "macro.h"
#include "grid.h"
#include "sparse.h"
#include "vec.h"
#include "fem.h"
#include "solver.h"
#include "nonlinear.h"
#include "timestep.h"
#include "param.h"
#include "graphs.h"
// Special Includes
#if WITH_MATLAB
#include "mex.h"
#endif

/* In file: src/assemble/assemble_global.c */
void assemble_global(dCSRmat* A,dvector *b,void (*local_assembly)(REAL *,fespace *,trimesh *,qcoordinates *,INT *,INT *,INT,void (*)(REAL *,REAL *,REAL),REAL),fespace *FE,trimesh *mesh,qcoordinates *cq,void (*rhs)(REAL *,REAL *,REAL),void (*coeff)(REAL *,REAL *,REAL),REAL time);
void assemble_global_withBC(dCSRmat* A,dvector *b,void (*local_assembly)(REAL *,fespace *,trimesh *,qcoordinates *,INT *,INT *,INT,void (*)(REAL *,REAL *,REAL),REAL),fespace *FE,trimesh *mesh,qcoordinates *cq,void (*rhs)(REAL *,REAL *,REAL),void (*bc)(REAL *,REAL *,REAL),void (*coeff)(REAL *,REAL *,REAL),REAL time) ;
void assemble_global_FE1FE2(dCSRmat* A,dvector *b,void (*local_assembly)(REAL *,fespace *,fespace *,trimesh *,qcoordinates *,INT *,INT *,INT *,INT,void (*)(REAL *,REAL *,REAL),REAL),fespace *FE1, fespace *FE2, trimesh *mesh,qcoordinates *cq,void (*rhs)(REAL *,REAL *,REAL),void (*coeff)(REAL *,REAL *,REAL),REAL time) ;
void assemble_global_block(block_dCSRmat* A,dvector *b,void (*local_assembly)(REAL *,block_fespace *,trimesh *,qcoordinates *,INT *,INT *,INT,REAL),void (*local_rhs_assembly)(REAL *,block_fespace *,trimesh *,qcoordinates *,INT *,INT *,INT,void (*)(REAL *,REAL *,REAL),REAL),block_fespace *FE,trimesh *mesh,qcoordinates *cq,void (*rhs)(REAL *,REAL *,REAL),REAL time);
void assemble_global_Jacobian(block_dCSRmat* A,dvector *b,dvector *old_sol,void (*local_assembly)(REAL *,dvector *,block_fespace *,trimesh *,qcoordinates *,INT *,INT *,INT,REAL),void (*local_rhs_assembly)(REAL *,dvector *,block_fespace *,trimesh *,qcoordinates *,INT *,INT *,INT,void (*)(REAL *,REAL *,REAL),REAL),block_fespace *FE,trimesh *mesh,qcoordinates *cq,void (*rhs)(REAL *,REAL *,REAL),REAL time) ;
void assemble_global_RHS(dvector *b,fespace *FE,trimesh *mesh,qcoordinates *cq,void (*rhs)(REAL *,REAL *,REAL),REAL time) ;
void assemble_global_RHS_block(dvector *b,void (*local_rhs_assembly)(REAL *,block_fespace *,trimesh *,qcoordinates *,INT *,INT *,INT,void (*)(REAL *,REAL *,REAL),REAL),block_fespace *FE,trimesh *mesh,qcoordinates *cq,void (*rhs)(REAL *,REAL *,REAL),REAL time);
void assemble_global_RHS_Jacobian(dvector *b,dvector *old_sol,void (*local_rhs_assembly)(REAL *,dvector *,block_fespace *,trimesh *,qcoordinates *,INT *,INT *,INT,void (*)(REAL *,REAL *,REAL),REAL),block_fespace *FE,trimesh *mesh,qcoordinates *cq,void (*rhs)(REAL *,REAL *,REAL),REAL time) ;
void assemble_global_face(dCSRmat* A,dvector* b,dvector *old_sol,void (*local_assembly_face)(REAL *,dvector *,fespace *,trimesh *,qcoordinates *,INT *,INT *,INT *,INT,INT,void (*)(REAL *,REAL *,REAL),REAL),void (*local_rhs_assembly_face)(REAL *,dvector *,fespace *,trimesh *,qcoordinates *,INT *,INT *,INT *,INT,INT,void (*)(REAL *,REAL *,REAL),REAL),fespace *FE,trimesh *mesh,qcoordinates *cq,void (*coeff)(REAL *,REAL *,REAL),void (*rhs)(REAL *,REAL *, REAL),REAL time,INT flag) ;
void assemble_global_RHS_face(dvector* b,dvector *old_sol,void (*local_rhs_assembly_face)(REAL *,dvector *,fespace *,trimesh *,qcoordinates *,INT *,INT *,INT *,INT,INT,INT,void (*)(REAL *,REAL *,REAL),REAL),fespace *FE,trimesh *mesh,qcoordinates *cq,void (*rhs)(REAL *,REAL *, REAL),REAL time,INT flag);
void assemble_global_Ned_GradH1_RHS(dvector *b,fespace *FE_H1,fespace *FE_Ned,trimesh *mesh,qcoordinates *cq,dvector* u) ;

/* In file: src/assemble/assemble_local.c */
void assemble_DuDv_local(REAL* ALoc,fespace *FE,trimesh *mesh,qcoordinates *cq,INT *dof_on_elm,INT *v_on_elm,INT elm,void (*coeff)(REAL *,REAL *,REAL),REAL time);
void assemble_mass_local(REAL* MLoc,fespace *FE,trimesh *mesh,qcoordinates *cq,INT *dof_on_elm,INT *v_on_elm,INT elm,void (*coeff)(REAL *,REAL *,REAL),REAL time);
void assemble_DuDvplusmass_local(REAL* ALoc,fespace *FE,trimesh *mesh,qcoordinates *cq,INT *dof_on_elm,INT *v_on_elm,INT elm,void (*coeff)(REAL *,REAL *,REAL),REAL time);
void boundary_mass_local(REAL* MLoc,dvector* old_sol,fespace *FE,trimesh *mesh,qcoordinates *cq, \
                         INT *dof_on_f,INT *dof_on_elm,INT *v_on_elm,INT face,INT elm,void (*coeff)(REAL *,REAL *,REAL),REAL time);
void FEM_RHS_Local(REAL* bLoc,fespace *FE,trimesh *mesh,qcoordinates *cq,INT *dof_on_elm,INT *v_on_elm,INT elm,void (*rhs)(REAL *,REAL *,REAL),REAL time);
void FEM_Block_RHS_Local(REAL* bLoc,block_fespace *FE,trimesh *mesh,qcoordinates *cq,INT *dof_on_elm,INT *v_on_elm,INT elm,void (*rhs)(REAL *,REAL *,REAL),REAL time);
void Ned_GradH1_RHS_local(REAL* bLoc,fespace *FE_H1,fespace *FE_Ned,trimesh *mesh,qcoordinates *cq,INT *ed_on_elm,INT *v_on_elm,INT elm,dvector* u)  ;
void FEM_RHS_Local_face(REAL* bLoc,dvector* old_sol,fespace *FE,trimesh *mesh,qcoordinates *cq,INT *dof_on_f,INT *dof_on_elm,INT *v_on_elm,INT dof_per_face,INT face,INT elm,void (*rhs)(REAL *,REAL *,REAL),REAL time);
void impedancebdry_local(REAL* ZLoc,dvector *old_sol,fespace *FE,trimesh *mesh,qcoordinates *cq,INT *ed_on_f, \
                         INT *ed_on_elm,INT *v_on_elm,INT face,INT elm,void (*coeff)(REAL *,REAL *,REAL),REAL time);

/* In file: src/assemble/assemble_utils.c */
void create_CSR_rows(dCSRmat *A, fespace *FE);
void create_CSR_rows_FE1FE2(dCSRmat *A, fespace *FE1, fespace *FE2);
void create_CSR_rows_withBC(dCSRmat *A, fespace *FE);
void create_CSR_rows_flag(dCSRmat *A, fespace *FE,INT flag);
void create_CSR_cols(dCSRmat *A, fespace *FE);
void create_CSR_cols_FE1FE2(dCSRmat *A, fespace *FE1, fespace *FE2);
void create_CSR_cols_withBC(dCSRmat *A, fespace *FE);
void create_CSR_cols_flag(dCSRmat *A, fespace *FE,INT flag);
void LocaltoGlobal(INT *dof_on_elm,fespace *FE,dvector *b,dCSRmat *A,REAL *ALoc,REAL *bLoc) ;
void LocaltoGlobal_FE1FE2(INT *dof_on_elm1,fespace *FE1,INT *dof_on_elm2,fespace *FE2,dvector *b,dCSRmat *A,REAL *ALoc,REAL *bLoc) ;
void block_LocaltoGlobal(INT *dof_on_elm,block_fespace *FE,dvector *b,block_dCSRmat *A,REAL *ALoc,REAL *bLoc);
void LocaltoGlobal_withBC(INT *dof_on_elm,fespace *FE,dvector *b,dCSRmat *A,REAL *ALoc,REAL *bLoc);
void LocaltoGlobal_face(INT *dof_on_f,INT dof_per_f,fespace *FE,dvector *b,dCSRmat *A,REAL *ALoc,REAL *bLoc,INT flag) ;
void eliminate_DirichletBC(void (*bc)(REAL *,REAL *,REAL),fespace *FE,trimesh *mesh,dvector *b,dCSRmat *A,REAL time) ;
void eliminate_DirichletBC_RHS(void (*bc)(REAL *,REAL *,REAL),fespace *FE,trimesh *mesh,dvector *b,dCSRmat *A,REAL time) ;
void block_eliminate_DirichletBC(void (*bc)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,dvector *b,
                                 void *A,INT Atype,REAL time);
void block_eliminate_DirichletBC_RHS(void (*bc)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,
                                     dvector *b,void *A,INT Atype,REAL time);
void eliminate_DirichletBC_blockFE(void (*bc)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,dvector *b,dCSRmat *A,REAL time) ;
void eliminate_DirichletBC_RHS_blockFE(void (*bc)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,dvector *b,dCSRmat *A,REAL time) ;
void eliminate_DirichletBC_blockFE_blockA(void (*bc)(REAL *, REAL *,REAL),block_fespace *FE,trimesh *mesh,dvector *b,
                                          block_dCSRmat *A,REAL time);
void eliminate_DirichletBC_RHS_blockFE_blockA(void (*bc)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,dvector *b,block_dCSRmat *A,REAL time) ;

/* In file: src/fem/basis.c */
void PX_H1_basis(REAL *p,REAL *dp,REAL *x,INT *dof,INT porder,trimesh *mesh);
void quad_tri_2D_2der(REAL *p,REAL *dpx,REAL *dpy,REAL *dpxx,REAL *dpyy,REAL *dpxy,REAL x,REAL y,REAL z,INT *dof,INT porder,trimesh *mesh) ;
void ned_basis(REAL *phi,REAL *cphi,REAL *x,INT *v_on_elm,INT *dof,trimesh *mesh);
void rt_basis(REAL *phi,REAL *dphi,REAL *x,INT *v_on_elm,INT *dof,trimesh *mesh);
void bdm1_basis(REAL *phi,REAL *dphix,REAL *dphiy,REAL *x,INT *v_on_elm,INT *dof,trimesh *mesh);
void bubble_face_basis(REAL *phi, REAL *dphi, REAL *x, INT *v_on_elm, INT *dof, trimesh *mesh);
void get_FEM_basis(REAL *phi,REAL *dphi,REAL *x,INT *v_on_elm,INT *dof,trimesh *mesh,fespace *FE);

/* In file: src/fem/eafe.c */
void eafe(dCSRmat *A, dvector *rhs,		\
	  void (*local_assembly)(REAL *,fespace *,trimesh *,qcoordinates *,INT *,INT *,INT,void (*)(REAL *,REAL *,REAL),REAL), \
	  trimesh mesh, fespace FE, qcoordinates *cq,	\
	  void (*scalar_val_d)(REAL *, REAL *, REAL),			\
	  void (*scalar_val_rhs)(REAL *, REAL *, REAL),			\
	  void (*vector_val_ad)(REAL *, REAL *, REAL),			\
	  void (*scalar_val_bndnr)(REAL *, REAL *, REAL), REAL faketime);

/* In file: src/fem/error.c */
REAL L2norm(REAL *u,fespace *FE,trimesh *mesh,qcoordinates *cq);
void L2norm_block(REAL *norm,REAL *u,block_fespace *FE,trimesh *mesh,qcoordinates *cq);
REAL L2_InnerProduct(REAL *u,REAL *v,fespace *FE,trimesh *mesh,qcoordinates *cq);
void L2_InnerProduct_block(REAL *prod,REAL *u,REAL *v,block_fespace *FE,trimesh *mesh,qcoordinates *cq);
REAL L2error(REAL *u,void (*truesol)(REAL *,REAL *,REAL),fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);
void L2error_block(REAL *err,REAL *u,void (*truesol)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);
REAL L2error_mass(REAL *u,void (*truesol)(REAL *,REAL *,REAL),fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);
void L2error_block_mass(REAL *err, REAL *u,void (*truesol)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);
REAL HDseminorm(REAL *u,fespace *FE,trimesh *mesh,qcoordinates *cq);
void HDseminorm_block(REAL *norm,REAL *u,block_fespace *FE,trimesh *mesh,qcoordinates *cq);
REAL HDsemierror(REAL *u,void (*D_truesol)(REAL *,REAL *,REAL),fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);
void HDsemierror_block(REAL *err,REAL *u,void (*D_truesol)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);
REAL HDsemierror_stiff(REAL *u,void (*truesol)(REAL *,REAL *,REAL),fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);
void HDsemierror_block_stiff(REAL *err, REAL *u,void (*truesol)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);
REAL HDnorm(REAL *u,fespace *FE,trimesh *mesh,qcoordinates *cq);
void HDnorm_block(REAL *norm,REAL *u,block_fespace *FE,trimesh *mesh,qcoordinates *cq);
REAL HDerror(REAL *u,void (*truesol)(REAL *,REAL *,REAL),void (*D_truesol)(REAL *,REAL *,REAL),fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);
void HDerror_block(REAL *err,REAL *u,void (*truesol)(REAL *,REAL *,REAL),void (*D_truesol)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,qcoordinates *cq,REAL time);

/* In file: src/fem/fespace.c */
void initialize_fespace(fespace *FE);
void create_fespace(fespace *FE,trimesh* mesh,INT FEtype);
void free_fespace(fespace* FE);
void free_blockfespace(block_fespace* FE);
void get_P2(fespace* FE,trimesh* mesh) ;
void dump_el_dof(FILE* fid,iCSRmat *el_dof) ;
void dump_fespace(fespace *FE,char *varname,char *dir) ;
void set_dirichlet_bdry(fespace* FE,trimesh* mesh,INT flag) ;
void set_dirichlet_bdry_block(block_fespace* FE,trimesh* mesh,INT flag) ;
void get_incidence_row(INT row,iCSRmat *fem_map,INT* thisrow);

/* In file: src/fem/interp.c */
void FE_Interpolation(REAL* val,REAL *u,REAL* x,INT *dof_on_elm,INT *v_on_elm,fespace *FE,trimesh *mesh,INT nun);
void FE_DerivativeInterpolation(REAL* val,REAL *u,REAL *x,INT *dof_on_elm,INT *v_on_elm,fespace *FE,trimesh *mesh,INT nun);
void FE_Evaluate(REAL* val,void (*expr)(REAL *,REAL *,REAL),fespace *FE,trimesh *mesh,REAL time);
REAL FE_Evaluate_DOF(void (*expr)(REAL *,REAL *,REAL),fespace *FE,trimesh *mesh,REAL time,INT DOF);
void blockFE_Interpolation(REAL* val,REAL *u,REAL* x,INT *dof_on_elm,INT *v_on_elm,block_fespace *FE,trimesh *mesh);
void blockFE_DerivativeInterpolation(REAL* val,REAL *u,REAL* x,INT *dof_on_elm,INT *v_on_elm,block_fespace *FE,trimesh *mesh);
void blockFE_Evaluate(REAL* val,void (*expr)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,REAL time);
REAL blockFE_Evaluate_DOF(void (*expr)(REAL *,REAL *,REAL),block_fespace *FE,trimesh *mesh,REAL time,INT comp,INT DOF);
void Project_to_Vertices(REAL* u_on_V,REAL *u,fespace *FE,trimesh *mesh,INT nun);
void get_unknown_component(dvector* u,dvector* ublock,block_fespace *FE,INT comp);
void set_unknown_component(dvector* u,dvector* ublock,block_fespace *FE,INT comp);
void get_grad_H1toNed(dCSRmat* Grad,trimesh* mesh);
void get_curl_NedtoRT(dCSRmat* Curl,trimesh* mesh);
void get_div_RTtoL2(dCSRmat* Div,trimesh* mesh);
void get_Pigrad_H1toNed(dCSRmat* Pgrad,trimesh* mesh);
void ProjectOut_Grad(dvector* u,fespace* FE_H1,fespace* FE_Ned,trimesh* mesh,qcoordinates* cq,dCSRmat* G);

/* In file: src/fem/quadrature.c */
struct qcoordinates *allocateqcoords(INT nq1d,INT nelm,INT mydim);
struct qcoordinates *allocateqcoords_bdry(INT nq1d,INT nelm,INT dim,INT ed_or_f);
void free_qcoords(qcoordinates* A);
qcoordinates* get_quadrature(trimesh *mesh,INT nq1d) ;
void quad_elm(qcoordinates *cqelm,trimesh *mesh,INT nq1d,INT elm) ;
qcoordinates* get_quadrature_boundary(trimesh *mesh,INT nq1d,INT ed_or_f) ;
void quad_edgeface(qcoordinates *cqbdry,trimesh *mesh,INT nq1d,INT dof,INT e_or_f) ;
void dump_qcoords(qcoordinates *q) ;
void quad1d(REAL *gaussp, REAL *gaussc, INT ng1d);
void triquad_(REAL *gp, REAL *gc, INT ng1d);
void tetquad_(REAL *gp, REAL *gc, INT ng1d);

/* In file: src/grid/grid.c */
void initialize_mesh(trimesh* mesh) ;
void creategrid_fread(FILE *gfid,INT file_type,trimesh* mesh) ;
void build_mesh(trimesh* mesh) ;
struct coordinates *allocatecoords(INT ndof,INT mydim);
void free_coords(coordinates* A);
void dump_coords(FILE* fid,coordinates *c) ;
void free_mesh(trimesh* mesh);

/* In file: src/grid/mesh_io.c */
void read_grid_haz(FILE *gfid,trimesh *mesh) ;
void read_grid_vtk(FILE *gfid,trimesh *mesh) ;
void dump_mesh_haz(char *namehaz,trimesh *mesh);
void dump_mesh_vtk(char *namevtk,trimesh *mesh);
void create1Dgrid_Line(trimesh* mesh,REAL left_end,REAL right_end,INT nelm);

/* In file: src/grid/mesh_stats.c */
iCSRmat convert_elmnode(INT *element_vertex,INT nelm,INT nv,INT nve) ;
iCSRmat get_edge_v(INT* nedge,iCSRmat* el_v);
void isboundary_ed(iCSRmat* f_ed,iCSRmat* ed_v,INT nedge,INT nface,INT *f_bdry,INT *v_bdry,INT *nbedge,INT *ed_bdry) ;
iCSRmat get_el_ed(iCSRmat* el_v,iCSRmat* ed_v);
void edge_stats_all(REAL *ed_len,REAL *ed_tau,REAL *ed_mid,coordinates *cv,iCSRmat* ed_v,INT dim);
void get_face_ordering(INT el_order,INT dim,INT f_order,INT *fel_order);
void get_face_maps(iCSRmat* el_v,INT el_order,iCSRmat* ed_v,INT nface,INT dim,INT f_order,iCSRmat *el_f,INT *f_bdry,INT *nbface,iCSRmat *f_v,iCSRmat *f_ed,INT *fel_order);
void find_facenumber(iCSRmat* el_v,INT elm,INT* nd,INT dim,INT *f_num);
void face_stats(REAL *f_area,REAL *f_mid,REAL *f_norm,iCSRmat *f_v,trimesh *mesh) ;
void sync_facenode(iCSRmat *f_v,REAL* f_norm,trimesh *mesh)           ;
void get_el_mid(REAL *el_mid,iCSRmat* el_v,coordinates *cv,INT dim);
void get_el_vol(REAL *el_vol,iCSRmat *el_v,coordinates *cv,INT dim,INT v_per_elm);

/* In file: src/nonlinear/newton.c */
void initialize_newton(newton *n_it,input_param *inparam);
void free_newton(newton* n_it);
void update_newtonstep(newton* n_it);
void update_sol_newton(newton *n_it);
int check_newton_convergence(newton *n_it,fespace* FE,trimesh* mesh, qcoordinates* cq);

/* In file: src/solver/amg_setup_ua.c */
void form_boolean_p(ivector *vertices,
                           dCSRmat *tentp,
                           INT levelNum,
                           INT num_aggregations);
SHORT amg_setup_ua (AMG_data *mgl,
                    AMG_param *param);

/* In file: itsolver_util.inl */
INT amg_solve(AMG_data *mgl,
              AMG_param *param);
INT amg_solve_amli (AMG_data *mgl,
                         AMG_param *param);
INT amg_solve_nl_amli(AMG_data *mgl,
                      AMG_param *param);

/* In file: src/solver/direct.c */
INT directsolve_UMF(dCSRmat *A,
                    dvector *f,
                    REAL *x,
                    INT print_level);
void* umfpack_factorize (dCSRmat *ptrA,
                         const SHORT prtlvl);
INT umfpack_solve (dCSRmat *ptrA,
                   dvector *b,
                   dvector *u,
                   void *Numeric,
                   const SHORT prtlvl);
INT umfpack_free_numeric (void *Numeric);

/* In file: src/solver/itsolver.c */
INT solver_dcsr_linear_itsolver(dCSRmat *A,
                                dvector *b,
                                dvector *x,
                                precond *pc,
                                linear_itsolver_param *itparam);
INT solver_bdcsr_linear_itsolver(block_dCSRmat *A,
                                 dvector *b,
                                 dvector *x,
                                 precond *pc,
                                 linear_itsolver_param *itparam);
INT solver_general_linear_itsolver(matvec *mxv,
                                   dvector *b,
                                   dvector *x,
                                   precond *pc,
                                   linear_itsolver_param *itparam);
INT linear_solver_amg(dCSRmat *A,
                      dvector *b,
                      dvector *x,
                      AMG_param *param);
INT linear_solver_dcsr_krylov(dCSRmat *A,
                             dvector *b,
                             dvector *x,
                             linear_itsolver_param *itparam);
INT linear_solver_dcsr_krylov_diag(dCSRmat *A,
                                   dvector *b,
                                   dvector *x,
                                   linear_itsolver_param *itparam);
INT linear_solver_dcsr_krylov_amg(dCSRmat *A,
                                  dvector *b,
                                  dvector *x,
                                  linear_itsolver_param *itparam,
                                  AMG_param *amgparam);
INT linear_solver_dcsr_krylov_hx_curl(dCSRmat *A,
                                      dvector *b,
                                      dvector *x,
                                      linear_itsolver_param *itparam,
                                      AMG_param *amgparam,
                                      dCSRmat *P_curl,
                                      dCSRmat *Grad);
INT linear_solver_bdcsr_krylov(block_dCSRmat *A,
                               dvector *b,
                               dvector *x,
                               linear_itsolver_param *itparam);
INT linear_solver_bdcsr_krylov_block_2(block_dCSRmat *A,
                                       dvector *b,
                                       dvector *x,
                                       linear_itsolver_param *itparam,
                                       AMG_param *amgparam,
                                       dCSRmat *A_diag);
INT linear_solver_bdcsr_krylov_block_3(block_dCSRmat *A,
                                       dvector *b,
                                       dvector *x,
                                       linear_itsolver_param *itparam,
                                       AMG_param *amgparam,
                                       dCSRmat *A_diag);
INT linear_solver_bdcsr_krylov_block_4(block_dCSRmat *A,
                                       dvector *b,
                                       dvector *x,
                                       linear_itsolver_param *itparam,
                                       AMG_param *amgparam,
                                       dCSRmat *A_diag);
INT linear_solver_bdcsr_krylov_mixed_darcy(block_dCSRmat *A,
                                           dvector *b,
                                           dvector *x,
                                           linear_itsolver_param *itparam,
                                           AMG_param *amgparam,
                                           dvector *el_vol);
INT linear_solver_bdcsr_krylov_biot_2phase(block_dCSRmat *A,
                                           dvector *b,
                                           dvector *x,
                                           linear_itsolver_param *itparam,
                                           AMG_param *amgparam,
                                           dCSRmat *Mp);
INT linear_solver_bdcsr_krylov_maxwell(block_dCSRmat *A,
                                       dvector *b,
                                       dvector *x,
                                       linear_itsolver_param *itparam,
                                       AMG_param *amgparam,
                                       dCSRmat *A_diag,
                                       dCSRmat *P_curl,
                                       dCSRmat *Grad,
                                       dCSRmat *Gb,
                                       dCSRmat *Kb,
                                       dCSRmat *Gtb,
                                       dCSRmat *Ktb);

/* In file: src/solver/krylov.c */

/* In file: itsolver_util.inl */
INT dcsr_pcg (dCSRmat *A,
              dvector *b,
              dvector *u,
              precond *pc,
              const REAL tol,
              const INT MaxIt,
              const SHORT stop_type,
              const SHORT prtlvl);
INT bdcsr_pcg (block_dCSRmat *A,
               dvector *b,
               dvector *u,
               precond *pc,
               const REAL tol,
               const INT MaxIt,
               const SHORT stop_type,
               const SHORT prtlvl);
INT general_pcg (matvec *mxv,
                 dvector *b,
                 dvector *u,
                 precond *pc,
                 const REAL tol,
                 const INT MaxIt,
                 const SHORT stop_type,
                 const SHORT prtlvl);
INT dcsr_pgcg(dCSRmat *A,
              dvector *b,
              dvector *u,
              precond *pc,
              const REAL tol,
              const INT MaxIt,
              const SHORT stop_type,
              const SHORT print_level);
INT dcsr_pminres(dCSRmat *A,
                 dvector *b,
                 dvector *u,
                 precond *pc,
                 const REAL tol,
                 const INT MaxIt,
                 const SHORT stop_type,
                 const SHORT prtlvl);
INT bdcsr_pminres(block_dCSRmat *A,
                  dvector *b,
                  dvector *u,
                  precond *pc,
                  const REAL tol,
                  const INT MaxIt,
                  const SHORT stop_type,
                  const SHORT prtlvl);
INT general_pminres(matvec *mxv,
                    dvector *b,
                  dvector *u,
                  precond *pc,
                  const REAL tol,
                  const INT MaxIt,
                  const SHORT stop_type,
                  const SHORT prtlvl);
INT dcsr_pvgmres (dCSRmat *A,
                  dvector *b,
                  dvector *x,
                  precond *pc,
                  const REAL tol,
                  const INT MaxIt,
                  const SHORT restart,
                  const SHORT stop_type,
                  const SHORT prtlvl);
INT bdcsr_pvgmres (block_dCSRmat *A,
                               dvector *b,
                               dvector *x,
                               precond *pc,
                               const REAL tol,
                               const INT MaxIt,
                               const SHORT restart,
                               const SHORT stop_type,
                               const SHORT prtlvl);
INT general_pvgmres (matvec *mxv,
                  dvector *b,
                  dvector *x,
                  precond *pc,
                  const REAL tol,
                  const INT MaxIt,
                  const SHORT restart,
                  const SHORT stop_type,
                  const SHORT prtlvl);
INT dcsr_pvfgmres(dCSRmat *A,
                  dvector *b,
                  dvector *x,
                  precond *pc,
                  const REAL tol,
                  const INT MaxIt,
                  const SHORT restart,
                  const SHORT stop_type,
                  const SHORT prtlvl);
INT bdcsr_pvfgmres(block_dCSRmat *A,
                   dvector *b,
                   dvector *x,
                   precond *pc,
                   const REAL tol,
                   const INT MaxIt,
                   const SHORT restart,
                   const SHORT stop_type,
                   const SHORT prtlvl);
INT general_pvfgmres(matvec *mxv,
                     dvector *b,
                     dvector *x,
                     precond *pc,
                     const REAL tol,
                     const INT MaxIt,
                     const SHORT restart,
                     const SHORT stop_type,
                     const SHORT prtlvl);

/* In file: src/solver/mgcycle.c */
void mgcycle(AMG_data *mgl,
             AMG_param *param);
void amli(AMG_data *mgl,
          AMG_param *param,
          INT level);
void nl_amli (AMG_data *mgl,
              AMG_param *param,
              INT level,
              INT num_levels);

/* In file: src/solver/precond.c */

/* In file: itsolver_util.inl */
void precond_diag (REAL *r, 
                        REAL *z, 
                        void *data);
void precond_amg(REAL *r,
                 REAL *z,
                 void *data);
void precond_amli(REAL *r,
                  REAL *z,
                  void *data);
void precond_nl_amli(REAL *r,
                     REAL *z,
                     void *data);
void precond_hx_curl_additive(REAL *r,
                              REAL *z,
                              void *data);
void precond_hx_curl_multiplicative(REAL *r,
                                    REAL *z,
                                    void *data);
void precond_block_diag_2(REAL *r,
                          REAL *z,
                          void *data);
void precond_block_lower_2(REAL *r,
                           REAL *z,
                           void *data);
void precond_block_upper_2(REAL *r,
                           REAL *z,
                           void *data);
void precond_block_diag_3(REAL *r,
                          REAL *z,
                          void *data);
void precond_block_lower_3(REAL *r,
                           REAL *z,
                           void *data);
void precond_block_upper_3(REAL *r,
                           REAL *z,
                           void *data);
void precond_block_diag_4(REAL *r,
                          REAL *z,
                          void *data);
void precond_block_lower_4(REAL *r,
                           REAL *z,
                           void *data);
void precond_block_upper_4(REAL *r,
                           REAL *z,
                           void *data);
void precond_block_diag_mixed_darcy(REAL *r,
                                    REAL *z,
                                    void *data);
void precond_block_lower_mixed_darcy(REAL *r,
                                    REAL *z,
                                    void *data);
void precond_block_upper_mixed_darcy(REAL *r,
                                     REAL *z,
                                     void *data);
void precond_block_diag_mixed_darcy_krylov(REAL *r,
                                           REAL *z,
                                           void *data);
void precond_block_lower_mixed_darcy_krylov(REAL *r,
                                            REAL *z,
                                            void *data);
void precond_block_upper_mixed_darcy_krylov(REAL *r,
                                            REAL *z,
                                            void *data);
void precond_block_diag_biot_2phase(REAL *r,
                                    REAL *z,
                                    void *data);
void precond_block_lower_biot_2phase(REAL *r,
                                     REAL *z,
                                     void *data);
void precond_block_upper_biot_2phase(REAL *r,
                                     REAL *z,
                                     void *data);
void precond_block_diag_biot_2phase_krylov(REAL *r,
                                           REAL *z,
                                           void *data);
void precond_block_lower_biot_2phase_krylov(REAL *r,
                                            REAL *z,
                                            void *data);
void precond_block_upper_biot_2phase_krylov(REAL *r,
                                            REAL *z,
                                            void *data);
void precond_block_diag_maxwell(REAL *r,
                                REAL *z,
                                void *data);
void precond_block_lower_maxwell(REAL *r,
                                 REAL *z,
                                 void *data);
void precond_block_upper_maxwell(REAL *r,
                                 REAL *z,
                                 void *data);
void precond_block_diag_maxwell_krylov(REAL *r,
                                       REAL *z,
                                       void *data);
void precond_block_lower_maxwell_krylov(REAL *r,
                                        REAL *z,
                                        void *data);
void precond_block_upper_maxwell_krylov(REAL *r,
                                        REAL *z,
                                        void *data);
void precond_block_lower_diag_maxwell(REAL *r,
                                      REAL *z,
                                      void *data);
void precond_block_diag_upper_maxwell(REAL *r,
                                      REAL *z,
                                      void *data);
void precond_block_lower_diag_upper_maxwell(REAL *r,
                                            REAL *z,
                                            void *data);
void precond_block_lower_diag_maxwell_krylov(REAL *r,
                                             REAL *z,
                                             void *data);
void precond_block_diag_upper_maxwell_krylov(REAL *r,
                                             REAL *z,
                                             void *data);
void precond_block_lower_diag_upper_maxwell_krylov(REAL *r,
                                                   REAL *z,
                                                   void *data);

/* In file: src/solver/smoother.c */
void smoother_dcsr_jacobi(dvector *u,
                          const INT i_1,
                          const INT i_n,
                          const INT s,
                          dCSRmat *A,
                          dvector *b,
                          INT L);
void smoother_dcsr_gs(dvector *u,
                      const INT i_1,
                      const INT i_n,
                      const INT s,
                      dCSRmat *A,
                      dvector *b,
                      INT L);
void smoother_dcsr_sgs(dvector *u,
                       dCSRmat *A,
                       dvector *b,
                       INT L);
void smoother_dcsr_sor(dvector *u,
                       const INT i_1,
                       const INT i_n,
                       const INT s,
                       dCSRmat *A,
                       dvector *b,
                       INT L,
                       const REAL w);
void smoother_dcsr_L1diag(dvector *u,
                          const INT i_1,
                          const INT i_n,
                          const INT s,
                          dCSRmat *A,
                          dvector *b,
                          INT L);

/* In file: src/utilities/array.c */
void array_null(REAL *x);
void iarray_null(INT *x);
void array_set (const INT n,
                REAL *x,
                const REAL val);
void iarray_set (const INT n,
                 INT *x,
                 const INT val);
void array_cp (const INT n,
               REAL *x,
               REAL *y);
void iarray_cp (const INT n, 
                INT *x,
                INT *y);
void array_shuffle(const INT n,
                   REAL *x);
void iarray_shuffle(const INT n,
                   INT *x);
void array_ax (const INT n,
               const REAL a,
               REAL *x);
void array_axpy (const INT n,
                 const REAL a,
                 REAL *x,
                 REAL *y);
void array_axpyz (const INT n,
                  const REAL a,
                  REAL *x,
                  REAL *y,
                  REAL *z);
void array_axpby (const INT n,
                  const REAL a,
                  REAL *x,
                  const REAL b,
                  REAL *y);
REAL array_dotprod (const INT n,
                    const REAL * x,
                    const REAL * y);
REAL array_norm1 (const INT n,
                  const REAL * x);
REAL array_norm2 (const INT n,
                  const REAL * x);
REAL array_norminf (const INT n,
                    const REAL * x);
REAL array_normp(const INT n,
                 const REAL * x,
                 const INT p);
void det3D(REAL *mydet,
           REAL* vec1,
           REAL* vec2,
           REAL* vec3);

/* In file: src/utilities/coefficient.c */
void constant_coeff_scal(REAL *val,
                         REAL *x,
                         REAL constval);
void constant_coeff_vec2D(REAL *val,
                          REAL *x,
                          REAL constval);
void constant_coeff_vec3D(REAL *val,
                          REAL *x,
                          REAL constval);
void zero_coeff_scal(REAL *val,
                     REAL *x,
                     REAL time);
void zero_coeff_vec2D(REAL *val,
                      REAL *x,
                      REAL time);
void zero_coeff_vec3D(REAL *val,
                      REAL *x,
                      REAL time);
void one_coeff_scal(REAL *val,
                    REAL *x,
                    REAL time);
void one_coeff_vec2D(REAL *val,
                     REAL *x,
                     REAL time);
void one_coeff_vec3D(REAL *val,
                     REAL *x,
                     REAL time);

/* In file: src/utilities/data.c */
void precond_data_null (precond_data *pcdata);
AMG_data *amg_data_create(SHORT max_levels);
void amg_data_free(AMG_data *mgl,
                   AMG_param *param);
void HX_curl_data_null (HX_curl_data *hxcurldata);
void HX_curl_data_free (HX_curl_data *hxcurldata,
                        SHORT flag);
void precond_null(precond *pcdata);
void precond_block_data_null(precond_block_data *precdata);
void precond_block_data_free(precond_block_data *precdata, const INT nb);

/* In file: src/utilities/format.c */
dCSRmat bdcsr_2_dcsr (block_dCSRmat *Ab);
block_dCSRmat dcsr_2_bdcsr (dCSRmat *A,
                            int bnum,
                            int *bsize);
SHORT dcoo_2_dcsr (dCOOmat *A,
                   dCSRmat *B);

/* In file: src/utilities/input.c */
void param_input (const char *filenm,
                  input_param *inparam);

/* In file: src/utilities/io.c */
void iarray_print(INT *vec,
                  INT n);
void array_print(REAL *vec,
                 INT n);
void ivector_write(const char *filename,
                   ivector *vec);
void dvector_print(FILE* fid,
                   dvector *b);
void ivector_print(FILE* fid,
                   ivector *b);
void csr_print_matlab(FILE* fid,
                      dCSRmat *A);
void icsr_print_matlab(FILE* fid,
                       iCSRmat *A);
void dvec_write (const char *filename,
                 dvector *vec);
void dcsr_write_dcoo (const char *filename,
                      dCSRmat *A);
void rveci_(FILE *fp,
            INT *vec,
            INT *nn);
void rvecd_(FILE *fp,
            REAL *vec,
            INT *nn);
FILE* HAZ_fopen(char *fname,
                char *mode );
void dump_sol_onV_vtk(char *namevtk,
                      trimesh *mesh,
                      REAL *sol,
                      INT ncomp);
void create_pvd(char *namepvd, INT nfiles,char *vtkfilename,char *filetype);

/* In file: src/utilities/message.c */
void print_itsolver_info(const INT  print_lvl,
                         const INT  stop_type,
                         const INT  iter,
                         const REAL rel_res,
                         const REAL abs_res,
                         const REAL factor);
void print_cputime(const char *message,
                   const REAL cputime);
void print_message(const INT print_lvl,
                   const char *message);
void print_amg_complexity(AMG_data *mgl,
                          const SHORT print_lvl);
void check_error(const SHORT status,
                 const char *func_name);
void error_extlib(const SHORT status, const char *func_name, \
		  const char *lib_name);

/* In file: src/utilities/parameters.c */
void param_input_init (input_param *inparam);
void param_amg_init (AMG_param *amgparam);
void param_linear_solver_init (linear_itsolver_param *itsparam);
void param_linear_solver_set (linear_itsolver_param *itsparam,
                       input_param *inparam);
void param_amg_set (AMG_param *amgparam,
                    input_param *inparam);
void param_linear_solver_print (linear_itsolver_param *itsparam);
void param_amg_print (AMG_param *amgparam);
void param_amg_to_prec (precond_data *pcdata,
                        AMG_param *amgparam);
void param_prec_to_amg (AMG_param *amgparam,
                        precond_data *pcdata);
void amg_amli_coef (const REAL lambda_max,
                    const REAL lambda_min,
                    const INT degree,
                    REAL *coef);

/* In file: src/utilities/sparse.c */
dCSRmat dcsr_create (const INT m,
                     const INT n,
                     const INT nnz);
dCSRmat dcsr_create_zeromatrix(const INT m,
                               const INT n,
                               const INT index_start);
dCSRmat dcsr_create_single_nnz_matrix(const INT m,
                                      const INT n,
                                      const INT row,
                                      const INT col,
                                      const REAL val,
                                      const INT index_start);
dCSRmat dcsr_create_identity_matrix(const INT m,
                                    const INT index_start);
void dcsr_alloc(const INT m,
                const INT n,
                const INT nnz,
                dCSRmat *A);
iCSRmat icsr_create(const INT m,
                    const INT n,
                    const INT nnz);
iCSRmat icsr_create_identity(const INT m,
                             const INT index_start);
void dcsr_free(dCSRmat *A);
void icsr_free(iCSRmat *A);
void dcsr_null(dCSRmat *A);
void icsr_null(iCSRmat *A);
dCSRmat dcsr_perm(dCSRmat *A,
                  INT *P);
void icsr_cp(iCSRmat *A,
             iCSRmat *B);
void dcsr_cp(dCSRmat *A,
             dCSRmat *B);
INT dcsr_trans(dCSRmat *A,
               dCSRmat *AT);
void dcsr_trans_1(dCSRmat *A,
                  dCSRmat *AT);
void icsr_trans(iCSRmat *A,
                iCSRmat *AT);
void icsr_trans_1(iCSRmat *A,
                  iCSRmat *AT);
void dcsr_compress(dCSRmat *A,
                   dCSRmat *B,
                   REAL dtol);
SHORT dcsr_compress_inplace(dCSRmat *A,
                            REAL dtol);
void dcsr_shift(dCSRmat *A,
                INT offset);
void icsr_shift(iCSRmat *A,
                INT offset);
INT dcsr_add(dCSRmat *A,
             const REAL alpha,
             dCSRmat *B,
             const REAL beta,
             dCSRmat *C);
INT dcsr_add_1(dCSRmat *A,
               const REAL alpha,
               dCSRmat *B,
               const REAL beta,
               dCSRmat *C);
void dcsr_axm(dCSRmat *A,
              const REAL alpha);
void dcsr_mxv(dCSRmat *A,
              REAL *x,
              REAL *y);
void dcsr_mxv_1(dCSRmat *A,
                REAL *x,
                REAL *y);
void dcsr_mxv_1_forts(void *At,
                      REAL *x,
                      REAL *y);
void dcsr_mxv_agg(dCSRmat *A,
                  REAL *x,
                  REAL *y);
void dcsr_aAxpy(const REAL alpha,
                dCSRmat *A,
                REAL *x,
                REAL *y);
void dcsr_aAxpy_1(const REAL alpha,
                  dCSRmat *A,
                  REAL *x,
                  REAL *y);
void dcsr_aAxpy_agg(const REAL alpha,
                    dCSRmat *A,
                    REAL *x,
                    REAL *y);
REAL dcsr_vmv(dCSRmat *A,
              REAL *x,
              REAL *y);
REAL dcsr_vmv_1(dCSRmat *A,
                REAL *x,
                REAL *y);
void dcsr_mxm(dCSRmat *A,
              dCSRmat *B,
              dCSRmat *C);
void dcsr_mxm_1(dCSRmat *A,
                dCSRmat *B,
                dCSRmat *C);
void icsr_mxm(iCSRmat *A,
              iCSRmat *B,
              iCSRmat *C);
void icsr_mxm_1(iCSRmat *A,
                iCSRmat *B,
                iCSRmat *C);
void icsr_mxm_symb(iCSRmat *A,
                   iCSRmat *B,
                   iCSRmat *C);
void icsr_mxm_symb_1(iCSRmat *A,
                     iCSRmat *B,
                     iCSRmat *C);
void icsr_mxm_symb_max(iCSRmat *A,
                       iCSRmat *B,
                       iCSRmat *C,
                       INT multmax);
void icsr_mxm_symb_max_1(iCSRmat *A,
                         iCSRmat *B,
                         iCSRmat *C,
                         INT multmax);
void dcsr_getdiag(INT n,
                  dCSRmat *A,
                  dvector *diag);
void dcsr_diagpref(dCSRmat *A);
void dcsr_rap(dCSRmat *R,
              dCSRmat *A,
              dCSRmat *P,
              dCSRmat *RAP);
void dcsr_rap_agg(dCSRmat *R,
                  dCSRmat *A,
                  dCSRmat *P,
                  dCSRmat *RAP);
SHORT dcsr_getblk(dCSRmat *A,
                  INT *Is,
                  INT *Js,
                  const INT m,
                  const INT n,
                  dCSRmat *B);
void dcsr_bandwith(dCSRmat *A,
                   INT *bndwith);
void bdcsr_alloc(const INT brow,
                 const INT bcol,
                 block_dCSRmat *A);
void bdcsr_free(block_dCSRmat *A);
void bdcsr_cp(block_dCSRmat *A,
              block_dCSRmat *B);
INT bdcsr_add(block_dCSRmat *A,
              const REAL alpha,
              block_dCSRmat *B,
              const REAL beta,
              block_dCSRmat *C);
INT bdcsr_add_1(block_dCSRmat *A,
                const REAL alpha,
                block_dCSRmat *B,
                const REAL beta,
                block_dCSRmat *C);
void bdcsr_aAxpy(const REAL alpha,
                 block_dCSRmat *A,
                 REAL *x,
                 REAL *y);
void bdcsr_mxv(block_dCSRmat *A,
               REAL *x,
               REAL *y);
void bdcsr_mxv_forts(void *At,
                     REAL *x,
                     REAL *y);

/* In file: src/utilities/timing.c */
void get_time (REAL *time);

/* In file: src/utilities/vec.c */
INT dvec_isnan (dvector *u);
INT ivec_isnan (ivector *u);
dvector dvec_create (const INT m);
ivector ivec_create (const INT m);
void dvec_alloc (const INT m,
                 dvector *u);
void ivec_alloc (const INT m,
                 ivector *u);
void dvec_free (dvector *u);
void ivec_free (ivector *u);
void dvec_null (dvector *u);
void ivec_null (ivector *u);
void dvec_rand (const INT n,
                dvector *u);
void dvec_rand_true (const INT n,
                     dvector *u);
void dvec_set (INT n,
               dvector *u,
               REAL val);
void ivec_set (INT n,
               ivector *u,
               const INT val);
void dvec_cp (dvector *x,
              dvector *y);
void ivec_cp (ivector *x,
              ivector *y);
REAL dvec_maxdiff (dvector *x,
                   dvector *y);
void dvec_ax (const REAL a,
              dvector *x);
void dvec_axpy (const REAL a,
                dvector *x,
                dvector *y);
void dvec_axpyz(const REAL a,
                dvector *x,
                dvector *y,
                dvector *z);
REAL dvec_dotprod (dvector *x,
                   dvector *y);
REAL dvec_relerr (dvector *x,
                  dvector *y);
REAL dvec_norm1 (dvector *x);
REAL dvec_norm2 (dvector *x);
REAL dvec_norminf (dvector *x);

/* In file: src/utilities/wrapper.c */
void python_wrapper_krylov_amg(INT *n,
                               INT *nnz,
                               INT *ia,
                               INT *ja,
                               REAL *a,
                               REAL *b,
                               REAL *u,
                               REAL *tol,
                               INT *maxit,
                               INT *print_lvl);

/* In file: src/timestepping/timestep.c */
void initialize_timestepper(timestepper *tstepper,input_param *inparam,INT rhs_timedep,INT ndof);
void free_timestepper(timestepper* ts);
void update_timestep(timestepper *tstepper);
void get_timeoperator(timestepper* ts,INT first_visit,INT cpyNoBC);
void update_time_rhs(timestepper *ts);
void initialize_blktimestepper(block_timestepper *tstepper,input_param *inparam,INT rhs_timedep,INT ndof,INT blksize);
void free_blktimestepper(block_timestepper* ts);
void update_blktimestep(block_timestepper *tstepper);
void get_blktimeoperator(block_timestepper* ts,INT first_visit,INT cpyNoBC);
void update_blktime_rhs(block_timestepper *ts);
void fixrhs_time(dvector* b,dvector* b_old,dCSRmat* M,dCSRmat* A,dvector* uprev,INT time_scheme,REAL dt,dvector* b_update);
void get_timeoperator_old(dCSRmat* M,dCSRmat* A,INT time_scheme,REAL dt,dCSRmat* Atime);
void csrreb(INT *nrow, INT *ncol, INT *nnzluo, \
	    INT *ia, INT *ja, REAL *a,       \
	    INT **jareb, REAL **areb);
INT check0(weights *elem1, weights *elem2);
INT check1(iweights *elem1, iweights *elem2);
void getp(INT *ie, INT *je, REAL *w, INT ne, INT *p);
void getpz(REAL *z, INT nv, INT *p);
void getpi(INT *iz, INT *maskv, INT nv, INT *p);
void bfs(INT nv, INT *ia, INT *ja, INT *ibfs, INT *jbfs,	\
	INT *maske, INT *p, INT *et, INT *lev, REAL *w,REAL *z);
void bfstree(INT root, INT nv, INT ne, INT *ia, INT *ja, INT *ibfs, INT *jbfs, \
	    INT *mask, INT *et, INT *lev, INT *ledge, REAL *w,REAL *wo) ;
void dfs00_(INT *nin, INT *ia, INT *ja, INT *nblko,INT *iblk, INT *jblk);
INT optree(INT *gradi, INT *gradj, INT *p, INT ne, INT n, INT *et, INT *net);

/* End of header file */
