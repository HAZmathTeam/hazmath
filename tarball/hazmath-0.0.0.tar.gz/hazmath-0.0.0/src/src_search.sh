echo ' '
echo 'HAZMAT'
grep $1 ./assemble/*.c
grep $1 ./fem/*.c
grep $1 ./grid/*.c
grep $1 ./graphs/*.c
grep $1 ./interfaces/*.c
grep $1 ./nonlinear/*.c
grep $1 ./solver/*.c
grep $1 ./timestepping/*.c
grep $1 ./utilities/*.c
echo ' '
echo 'HDEquation'
grep $1 ../examples/HDEquation/*.c
echo ' '
echo 'Heat Equation'
grep $1 ../examples/HeatEquation/*.c
echo ' '
echo 'Stokes'
grep $1 ../examples/Stokes/*.c
grep $1 ../examples/Stokes/*.h
echo ' '
echo 'Darcy'
grep $1 ../examples/DarcyFlow/*.c
grep $1 ../examples/DarcyFlow/*.h
echo ' '
echo 'Maxwell'
grep $1 ../examples/Maxwell/*.c
grep $1 ../examples/Maxwell/*.h
