/*! \file src/utilities/alloc.c
 *
 *  Created by James Adler, Xiaozhe Hu, and Ludmil Zikatanov on 5/13/15.
 *  Copyright 2016__HAZMATH__. All rights reserved.
 *
 *  memory allocating functions using void arrays for structures.  
 *
 *  
 */
